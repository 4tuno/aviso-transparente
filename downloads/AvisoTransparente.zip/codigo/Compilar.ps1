$ErrorActionPreference = 'Stop'
$avisoCompiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $avisoCompiler)) { throw 'No se encontro el compilador de .NET Framework de 64 bits.' }
$avisoSource = Join-Path $PSScriptRoot 'AvisoTransparente.cs'
$avisoManifest = Join-Path $PSScriptRoot 'AvisoTransparente.manifest'
$avisoDestination = Join-Path (Split-Path -Parent $PSScriptRoot) 'AvisoTransparente.exe'
& $avisoCompiler /nologo /optimize+ /target:winexe /platform:x64 "/win32manifest:$avisoManifest" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll "/out:$avisoDestination" $avisoSource
if ($LASTEXITCODE -ne 0) { throw 'La compilacion fallo. Si la app esta abierta, cierrala primero.' }
Write-Output "Compilado: $avisoDestination"
